package com.id.sales_spring_batch;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;



/**
 * @author aissa.toubal
 *
 */
@Component
public class ProductWriter implements ItemWriter<ProductOutput> {	
	
	private static final String SALES_TAXE = "Sales Taxes:";
	private static final String TOTAL_TTC = "Total:";
	//écrire le résultas
	@SuppressWarnings("static-access")
	@Override
	public void write(List<? extends ProductOutput> items) throws Exception {
    	BigDecimal totolTTC = BigDecimal.ZERO;
    	BigDecimal totolTax = BigDecimal.ZERO;
    	
        for (ProductOutput item : items) {	                    
            totolTTC = totolTTC.add(item.getPrice());
            totolTax = totolTax.add(item.getTaxe());
            System.out.println(item.getName() + ": " + item.getPrice().toString());
        }	                
        System.out.println(this.SALES_TAXE + totolTax.toString() + " " + this.TOTAL_TTC + " " + totolTTC.toString());		
	}

}
