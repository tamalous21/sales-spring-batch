package com.id.sales_spring_batch;

/**
 * @author aissa.toubal
 *
 */
public class ProductInput {
	
	private String name;
	private String priceStr;

	
	public ProductInput() {
		
	}
		
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 */
	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return
	 */
	public String getPriceStr() {
		return priceStr;
	}

	/**
	 * @param priceStr
	 */
	public void setPriceStr(String priceStr) {
		this.priceStr = priceStr;
	}
}
