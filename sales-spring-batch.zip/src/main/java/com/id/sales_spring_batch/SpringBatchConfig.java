package com.id.sales_spring_batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;


/**
 * @author aissa.toubal
 *
 */
@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {	

	 @Autowired private JobBuilderFactory jobBuilderFactory;
	 @Autowired private StepBuilderFactory stepBuilderFactory;
	 @Autowired private ItemProcessor<ProductInput, ProductOutput> productProcessor;
	 @Autowired private ItemWriter<ProductOutput> productWriter;
	 
	// d�finition du job
    @Bean
    public Job job() {
        return jobBuilderFactory.get("job")
                .start(step())
                .build();
    }
    
    // d�finition de l'�tape step
    @Bean
    public Step step() {
        return stepBuilderFactory.get("step")
                .<ProductInput, ProductOutput>chunk(10)
                .reader(reader())
                .processor(productProcessor)
                .writer(productWriter)
                .build();
    }
    
    //d�finition de lecteur de fichier input
	@Bean
    public FlatFileItemReader<ProductInput> reader() {
        FlatFileItemReader<ProductInput> reader = new FlatFileItemReader<>();
        reader.setName("csvSalesReader");
        reader.setResource(new FileSystemResource("src/main/resources/sales-input-total.csv"));
        reader.setLineMapper(lineMapper());          
            return reader;
 
    }
	
	//permet de mapper une ligne du fichier en un objet 
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Bean
	public LineMapper<ProductInput> lineMapper() {
		DefaultLineMapper<ProductInput>  lineMapper = new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter(" at ");
		lineTokenizer.setStrict(false);
		lineTokenizer.setNames("name", "priceStr");
		lineMapper.setLineTokenizer(lineTokenizer);
		BeanWrapperFieldSetMapper fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(ProductInput.class);
		lineMapper.setFieldSetMapper(fieldSetMapper);
		return lineMapper;
	}

}
