package com.id.sales_spring_batch;

import java.math.BigDecimal;

/**
 * @author aissa.toubal
 *
 */
public class ProductOutput {
	private String name;	
	private BigDecimal price;
	private EnumTypeProduct type;
	private BigDecimal taxe;
	
	public ProductOutput() {
		
	}
	
	public ProductOutput(String name, String priceStr, EnumTypeProduct type) {
		this.name = name;
		this.price = new BigDecimal(priceStr);
		this.type = type;
	}
	
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}	

	/**
	 * @return
	 */
	public BigDecimal getPrice() {
		return price;
	}

	/**
	 * @param price
	 */
	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	/**
	 * @return
	 */
	public EnumTypeProduct getType() {
		return type;
	}
	/**
	 * @param type
	 */
	public void setType(EnumTypeProduct type) {
		this.type = type;
	}
	
	/**
	 * @return
	 */
	public BigDecimal getTaxe() {
		return taxe;
	}
	
	/**
	 * @param taxe
	 */
	public void setTaxe(BigDecimal taxe) {
		this.taxe = taxe;
	}
	
	/**
	 * @return
	 */
	public boolean isSalesTaxable() {
		return !this.type.isExempted();
	}
	
	/**
	 * @return
	 */
	public boolean isImportedTaxable() {
		return this.type.isImported();
	}
}
