package com.id.sales_spring_batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * @author aissa.toubal
 *
 */
@SpringBootApplication
public class SalesSpringBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesSpringBatchApplication.class, args);
	}
	//ça permet de lancer le job Spring Batch dès que l'application démarre
    @Bean
    public CommandLineRunner run(JobLauncher jobLauncher, Job job) {
        return args -> {
            try {
                // Lancer le job Spring Batch
                jobLauncher.run(job, new JobParameters());
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

}
