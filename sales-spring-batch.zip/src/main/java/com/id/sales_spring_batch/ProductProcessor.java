package com.id.sales_spring_batch;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;



/**
 * @author aissa.toubal
 *
 */
@Component
public class ProductProcessor implements ItemProcessor<ProductInput, ProductOutput>{
	
	@Override
	public ProductOutput process(ProductInput product) throws Exception {
		
		//si la ligne contient le mot imported
		boolean isImported = product.getName().contains("imported");
		// la liste des produits exonérés
		String[] exemptedItems =  new String[]{"book","chocolate","pills"};
    	// le type d'exonération
    	int exemptedItemIndex = containsItemFromArray(product.getName(),exemptedItems);  	
    	
    	String exemptedType = null;
    	
    	if(exemptedItemIndex != -1){    		
    		//le mot exonéné trouvé
    		exemptedType = exemptedItems[exemptedItemIndex];			
    	}
    	//return le bean transformé 
    	ProductOutput newProduct = transformeProduct(product, isImported, exemptedType);
    	//changer la position du mot imported s'il exist dans la name
    	newProduct.setName(ChangePosition(newProduct.getName()));
    	//calcu la taxe appliquée sur le produit
    	BigDecimal taxSum = calculateTaxProduct(newProduct);
    	newProduct.setTaxe(taxSum);
    	newProduct.setPrice(newProduct.getPrice().add(taxSum));    	
		return newProduct;
	}
	
	public ProductOutput  transformeProduct(ProductInput product, boolean isImported, String exemptedType) {
		ProductOutput newProduct = null;
    	if(isImported){
    		//le produit est importé
        	if(exemptedType != null){
        		//le produit est importé et et sa vente est exonéré de la taxe de vente
        		
        		if(exemptedType == "book"){
        			newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.IMPORTED_BOOK);
        		} else if(exemptedType == "pills"){
        			newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.IMPORTED_MEDICAL);
        		} else if(exemptedType == "chocolate"){
        			newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.IMPORTED_FOOD);
        		}

        	} else {
        		//le produit est importé  et sa vente est taxée
        		newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.IMPORTED_OTHERS);
        	}        	
    	} else {
    		//le produit n'est pas importé
        	if(exemptedType != null){
        		//le produit n'est pas importé et sa vente est exonéré de la taxe de vente        		
        		if(exemptedType == "book"){
        			newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.BOOK);
        		} else if(exemptedType == "pills"){
        			newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.MEDICAL);
        		} else if(exemptedType == "chocolate"){
        			newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.FOOD);
        		}

        	} else {
        		//le produit n'est pas importé et sa vente est taxée
        		newProduct = new ProductOutput(product.getName(), product.getPriceStr(), EnumTypeProduct.OTHERS);
        	}
    	}
    	return newProduct;
	}
	/*
	 * Cette méthode renvoie l'index dont la chaîne dans les éléments a été trouvée dans la chaîne d'entrée
	 *  -1 est renvoyé si aucun élement de la liste "iems" trouvé dans la chaine inputString
	 */
	public static int containsItemFromArray(String inputString, String[] items) {
		int index = -1;		
		for(int i = 0;i<items.length;i++){			
			index = inputString.indexOf(items[i]);
			if(index != -1)
				return i;			
		}
		return -1;		
	}
	//calcul de la taxe appliqué sur le produit
	public static BigDecimal  calculateTaxProduct(ProductOutput product) {
		
		BigDecimal taxSum = new BigDecimal("0.00");
		BigDecimal priceBeforeTax = new BigDecimal(String.valueOf(product.getPrice()));		
		//si le produit n'est pas exonéré de la taxe de vente
		if(product.isSalesTaxable()){
			//taxe de 10% et arrondi à 0,05
		
		    BigDecimal salesTaxPercent = new BigDecimal(".10");
		    BigDecimal salesTax = salesTaxPercent.multiply(priceBeforeTax);
		    
		    salesTax = round(salesTax, BigDecimal.valueOf(0.05), RoundingMode.UP);
		    taxSum = taxSum.add(salesTax);
		} 
		// si le produit est importé 
		if(product.isImportedTaxable()){
			//taxe de 5% et arrondi à 0,05

		    BigDecimal importTaxPercent = new BigDecimal(".05");
		    BigDecimal importTax = importTaxPercent.multiply(priceBeforeTax);
		    
		    importTax = round(importTax, BigDecimal.valueOf(0.05), RoundingMode.UP);
		    taxSum = taxSum.add(importTax);
		   
		}
		taxSum = round(taxSum, BigDecimal.valueOf(0.05), RoundingMode.UP);
		return taxSum;
	}
	/*
	 * Cette méthode gère l'arrondi à 0,05
	 * 
	 */
	public static BigDecimal round(BigDecimal value, BigDecimal increment,RoundingMode roundingMode) {

		if (increment.signum() == 0) {		
		return value;
		} else {
			BigDecimal divided = value.divide(increment, 0, roundingMode);
			BigDecimal result = divided.multiply(increment);
			result.setScale(2, RoundingMode.UNNECESSARY);
			return result;
		}
	}
	/*
	 * changer la position de mot imported en posision 1 s'il exist
	 * 
	 */
	public String ChangePosition (String chaineInput) {	
		List<String> mots = new ArrayList<>(Arrays.asList(chaineInput.split(" ")));
        if (mots.contains("imported")) {
            // Supprimer "imported" de sa position actuelle
        	mots.remove("imported");

            // Ajouter "imported" après le premier mot (position 1)
        	mots.add(1, "imported");
        }
        return String.join(" ", mots);
    }


}
