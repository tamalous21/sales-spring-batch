package com.id.sales_spring_batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesSpringBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
